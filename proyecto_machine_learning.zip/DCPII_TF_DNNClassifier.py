from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import tensorflow as tf
import numpy as np
import collections

STEPS = 250000  #number of steps we want to train our model

url = "./DigitalChain_PhaseII_DNN_dataset_20180228.csv" #path to the csv which contains the data
defaults = collections.OrderedDict([ #ordered list of the csv columns
    ("ECONOMIC_GROUP", [""]),
    ("COMPANY", [""]),
    ("PURCHASED_QUANTITY", [0]),
    ("DIFFERENCE", [0]),
    ("AMOUNT", [0.0]),
    ("CURRENCY", [""]),
    ("FINANCIAL_OFFER_TYPE", [0]),
    ("COUNTRY", [""]),
    ("SECTOR", [0]),
    ("TRADE", [""]),
    ("RATING", [0]),
    ("ORDERTYPE", [""])
#    ("SECTOR", [""]),
#    ("BRANCH", [""]),
#    ("RATING", [""]),
#    ("PRODUCT_OFFERED", [""])
])

#y_name is the column we want to predict
#we are useing 70% of the data as train data and 30% as test data
def dataset(y_name="FINANCIAL_OFFER_TYPE", train_fraction=0.7): 
  """Load the data as a (train,test) pair of `Dataset`.
  Each dataset generates (features_dict, label) pairs.
  Args:
    y_name: The name of the column to use as the label.
    train_fraction: A float, the fraction of data to use for training. The
        remainder will be used for evaluation.
  Returns:
    A (train,test) pair of `Datasets`
  """
  # Download and cache the data
  path = url

  # Define how the lines of the file should be parsed
  def decode_line(line):
    """Convert a csv line into a (features_dict,label) pair."""
    # Decode the line to a tuple of items based on the types of
    # csv_header.values().
    items = tf.decode_csv(line, list(defaults.values()))

    # Convert the keys and items to a dict.
    pairs = zip(defaults.keys(), items)
    features_dict = dict(pairs)

    # Remove the label from the features_dict
    label = features_dict.pop(y_name)

    return features_dict, label

  #check for nulls
  def has_no_question_marks(line):
    """Returns True if the line of text has no question marks."""
    # split the line into an array of characters
    chars = tf.string_split(line[tf.newaxis], "").values
    # for each character check if it is a question mark
    is_question = tf.equal(chars, "?")
    any_question = tf.reduce_any(is_question)
    no_question = ~any_question

    return no_question

  def in_training_set(line):
    """Returns a boolean tensor, true if the line is in the training set."""
    # If you randomly split the dataset you won't get the same split in both
    # sessions if you stop and restart training later. Also a simple
    # random split won't work with a dataset that's too big to `.cache()` as
    # we are doing here.
    num_buckets = 1000000
    bucket_id = tf.string_to_hash_bucket_fast(line, num_buckets)
    # Use the hash bucket id as a random number that's deterministic per example
    return bucket_id < int(train_fraction * num_buckets)

  def in_test_set(line):
    """Returns a boolean tensor, true if the line is in the training set."""
    # Items not in the training set are in the test set.
    # This line must use `~` instead of `not` because `not` only works on python
    # booleans but we are dealing with symbolic tensors.
    return ~in_training_set(line)

  base_dataset = (tf.contrib.data
                  # Get the lines from the file.
                  .TextLineDataset(path)
                  # drop lines with question marks.
                  .filter(has_no_question_marks))

  train = (base_dataset
           # Take only the training-set lines.
           .filter(in_training_set)
           # Decode each line into a (features_dict, label) pair.
           .map(decode_line)
           # Cache data so you only decode the file once.
           .cache())

  # Do the same for the test-set.
  test = (base_dataset.filter(in_test_set).cache().map(decode_line))

  return train, test



def main(argv):
  """Builds, trains, and evaluates the model."""
  (train, test) = dataset()

  # Build the training input_fn.
  def input_train():
    return (
        # Shuffling with a buffer larger than the data set ensures
        # that the examples are well mixed.
        train.shuffle(250000).batch(200) #each step will have 200 entries
        .repeat().make_one_shot_iterator().get_next())

  # Build the validation input_fn.
  def input_test():
    return (test.shuffle(25000).batch(2000) #select 200 random entries from the test_data
            .make_one_shot_iterator().get_next())
    
economic_group = tf.feature_column.categorical_column_with_hash_bucket(
    'ECONOMIC_GROUP', hash_bucket_size=1000)
#  company = tf.feature_column.categorical_column_with_vocabulary_list(
#        key='COMPANY',
#        vocabulary_list=["2300","1004","1000","1","6","3002","3001","2000","2200","1001","1002","1003","1710","SDCE","8","3003","3004","3005","3006","3007","3008","3009","3010","3011","3012","3013","3014","3015","3016","3017","3018","3019","3020","3000","1010","AX01","AEDE","BPOB","BPOC","BPOM","BPOP","BPSP","CARC","CCHI","CESP","CHOL","CMOR","EBEL","EBPX","EITS","ELUX","EPER","EVAN","EVAR","EVIN","EVUK","EXEL","5"])
  company = tf.feature_column.categorical_column_with_hash_bucket(
    'COMPANY', hash_bucket_size=1000)  
#  currency = tf.feature_column.categorical_column_with_vocabulary_list(
#        key='CURRENCY',
#        vocabulary_list=["","EUR","GBP","MXN","USD","VEB"])
  currency = tf.feature_column.categorical_column_with_hash_bucket(
    'CURRENCY', hash_bucket_size=1000)  
#  country = tf.feature_column.categorical_column_with_vocabulary_list(
#        key='COUNTRY',
#        vocabulary_list=["","ES","DE","US"])
  country = tf.feature_column.categorical_column_with_hash_bucket(
    'COUNTRY', hash_bucket_size=1000)  
#  trade = tf.feature_column.categorical_column_with_vocabulary_list(
#        key='TRADE',
#        vocabulary_list=["","TRAD","TRAN","MBAU","MEDI","HITE","MFTG","SECU","0002","CHEM","FOOD","SERV","CONS","0001","MUNI","PHAR","BLD"])
  trade = tf.feature_column.categorical_column_with_hash_bucket(
    'TRADE', hash_bucket_size=1000)  
#  ordertype = tf.feature_column.categorical_column_with_vocabulary_list(
#        key='ORDERTYPE',
#        vocabulary_list=["","NB","ZBPO","ZMPO","ZOTH","ZRAP","ZRES","ZSUB","ZTRA"])
  ordertype = tf.feature_column.categorical_column_with_hash_bucket(
    'ORDERTYPE', hash_bucket_size=1000)
  
  feature_columns = [
      #tf.feature_column.indicator_column(economic_group),
      #tf.feature_column.indicator_column(company),
      #tf.feature_column.numeric_column(key="PURCHASED_QUANTITY"),
      tf.feature_column.numeric_column(key="AMOUNT"),
      #tf.feature_column.indicator_column(currency),
      #tf.feature_column.indicator_column(country),
      #tf.feature_column.numeric_column(key="SECTOR"),
      #tf.feature_column.indicator_column(trade),
      tf.feature_column.numeric_column(key="RATING", dtype=tf.int32),
      #tf.feature_column.indicator_column(ordertype)
  ]

  model = tf.estimator.DNNClassifier(
          feature_columns=feature_columns,
          hidden_units=[20,10], # 2 hidden layers of 20 and 10 neurons
          n_classes=4,
      model_dir="./model/modelclasiftodo/hidden_20_10")

  #Train the model.
  checkpoints = 250 #STEPS/1000
  for i in range(checkpoints):#checkpoints):
      model.train(input_fn=input_train, steps=(STEPS/checkpoints))
      # Evaluate the model every 1000 steps
      eval_result = model.evaluate(input_fn=input_test) # Evaluate how the model performs on data it has not yet seen.
      print("\n" + 10 * "*")
      accuracy_score = eval_result["accuracy"]*100  # percent %
      print("\nTest Accuracy: {0:f}%\n".format(accuracy_score))
      print()
      

  
  
  #export modelo
  def json_serving_input_fn():
      inputs = {}
      for feat in feature_columns:
          inputs[feat.name] = tf.placeholder(shape=[None], dtype=feat.dtype)
      return tf.estimator.export.ServingInputReceiver(inputs, inputs)
  
  model.export_savedmodel(".\export_model\modelest", serving_input_receiver_fn= json_serving_input_fn)
  


if __name__ == "__main__":
  tf.logging.set_verbosity(tf.logging.INFO)
  main('1')